package com.example.demorest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemorestApplicationTests {

	@Test
	void contextLoads() {
	}

}
